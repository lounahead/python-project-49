from brain_games.logic import logic
from brain_games.games import calc


def main():
    logic(calc)


if __name__ == '__main__':
    main()
