### Hexlet tests and linter status:
[![Actions Status](https://github.com/lounahead/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/lounahead/python-project-49/actions)

<a href="https://codeclimate.com/github/lounahead/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/26173e5fba6cc2e5d558/maintainability" /></a> - online linter

https://asciinema.org/a/534840 - my asciinema for brain-even

https://asciinema.org/a/549836 - my asciinema for brain-calc

https://asciinema.org/a/550421 - my asciinema for brain-gcd

https://asciinema.org/a/550433 - my asciinema for brain-progression

https://asciinema.org/a/550470 - my asciinema for brain-prime